declare module 'brace/*' {
  let brace: any;
  export default brace;
}
